package com.gift.finder.app.constants;

public interface GiftFinderConstants {

	/* MySql DB Details */
	public static final String MYSQL_HOST = "localhost";
	public static final String MYSQL_PORT = "3306";
	public static final String MYSQL_DB_NAME = "giftFinder";
	public static final String MYSQL_USER = "root";
	public static final String MYSQL_PWD = "";
	
	
}
