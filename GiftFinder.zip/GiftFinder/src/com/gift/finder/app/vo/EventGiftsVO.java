package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.gift.finder.app.db.MySqlDb;

public class EventGiftsVO {
	private EventsVO eventId;
	private GiftsVO giftId;
	private GiftStatusVO eventGiftStatus;
	
	public EventGiftsVO() {
		// TODO Auto-generated constructor stub
	}
	
	public EventGiftsVO(EventsVO eventId, GiftsVO giftId, GiftStatusVO eventGiftStatus) {
		this.eventId = eventId;
		this.giftId = giftId;
		this.eventGiftStatus = eventGiftStatus;
	}

	public EventGiftsVO(EventsVO eventId, GiftsVO giftId)
	{
		this.eventId = eventId;
		this.giftId = giftId;
		getEventGift();
	}
	
	public void getEventGift()
	{
		MySqlDb db = new MySqlDb();
		String query = "select * from event_gifts where event_id = '"+eventId.getEventId()+"' and gift_id = '"+giftId.getGiftId()+"'";
		try {
			ResultSet rs = db.query(query);
			if(rs != null)
			{
				while(rs.next())
				{
					this.eventId = new EventsVO(rs.getString(1));
					this.giftId = new GiftsVO(rs.getString(2));
					this.eventGiftStatus = new GiftStatusVO(rs.getString(3));
				}
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public EventsVO getEventId() {
		return eventId;
	}
	public void setEventId(EventsVO eventId) {
		this.eventId = eventId;
	}
	public GiftsVO getGiftId() {
		return giftId;
	}
	public void setGiftId(GiftsVO giftId) {
		this.giftId = giftId;
	}
	public GiftStatusVO getEventGiftStatus() {
		return eventGiftStatus;
	}
	public void setEventGiftStatus(GiftStatusVO eventGiftStatus) {
		this.eventGiftStatus = eventGiftStatus;
	}
	
	
	

}
