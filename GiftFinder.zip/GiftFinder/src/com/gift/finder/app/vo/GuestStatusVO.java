package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.gift.finder.app.db.MySqlDb;

public class GuestStatusVO {
	private String guestStatusId;
	private String guestStatusName;
	private String guestStatusDesc;

	public GuestStatusVO() {
		// TODO Auto-generated constructor stub
	}

	public GuestStatusVO(String guestStatusId, String guestStatusName, String guestStatusDesc) {
		this.guestStatusId = guestStatusId;
		this.guestStatusName = guestStatusName;
		this.guestStatusDesc = guestStatusDesc;
	}

	public GuestStatusVO(String guestStatusId) {
		this.guestStatusId = guestStatusId;
		getGuestStatus();
	}

	public void getGuestStatus() {
		MySqlDb db = new MySqlDb();
		String query = "select * from guest_status where guest_status_id = '" + this.guestStatusId + "'";
		try {
			ResultSet rs = db.query(query);
			if (rs != null) {
				while (rs.next()) {
					this.guestStatusId = rs.getString(1);
					this.guestStatusName = rs.getString(2);
					this.guestStatusDesc = rs.getString(3);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getGuestStatusId() {
		return guestStatusId;
	}

	public void setGuestStatusId(String guestStatusId) {
		this.guestStatusId = guestStatusId;
	}

	public String getGuestStatusName() {
		return guestStatusName;
	}

	public void setGuestStatusName(String guestStatusName) {
		this.guestStatusName = guestStatusName;
	}

	public String getGuestStatusDesc() {
		return guestStatusDesc;
	}

	public void setGuestStatusDesc(String guestStatusDesc) {
		this.guestStatusDesc = guestStatusDesc;
	}

}
