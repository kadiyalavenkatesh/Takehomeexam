package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.gift.finder.app.db.MySqlDb;

public class GiftStatusVO {
	private String giftStatusId;
	private String giftStatusName;
	private String giftStatusDesc;
	
	public GiftStatusVO() {
		
	}
	
	public GiftStatusVO(String giftStatusId, String giftStatusName, String giftStatusDesc) {
		this.giftStatusId = giftStatusId;
		this.giftStatusName = giftStatusName;
		this.giftStatusDesc = giftStatusDesc;
	}
	
	public GiftStatusVO(String giftStatusId)
	{
		this.giftStatusId = giftStatusId;
		getGiftStatus();
	}
	
	public void getGiftStatus()
	{
		MySqlDb db = new MySqlDb();
		String query = "select * from gift_status where gift_status_id = '"+this.giftStatusId+"'";
		try {
			ResultSet rs = db.query(query);
			if(rs != null)
			{
				while(rs.next())
				{
					this.giftStatusId = rs.getString(1);
					this.giftStatusName = rs.getString(2);
					this.giftStatusDesc = rs.getString(3);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public String getGiftStatusId() {
		return giftStatusId;
	}
	
	public void setGiftStatusId(String giftStatusId) {
		this.giftStatusId = giftStatusId;
	}
	public String getGiftStatusName() {
		return giftStatusName;
	}
	public void setGiftStatusName(String giftStatusName) {
		this.giftStatusName = giftStatusName;
	}
	public String getGiftStatusDesc() {
		return giftStatusDesc;
	}
	public void setGiftStatusDesc(String giftStatusDesc) {
		this.giftStatusDesc = giftStatusDesc;
	}
	

}
