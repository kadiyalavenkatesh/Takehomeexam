package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.gift.finder.app.db.MySqlDb;

public class EventsVO {
	private String eventId;
	private String eventName;
	private String eventDesc;
	private Date eventStart;
	private Date eventEnd;
	private UserVO eventUserId;
	private String eventLocation;
	private String eventAddress;
	private EventTypesVO eventType;

	public EventsVO() {
		// TODO Auto-generated constructor stub
	}

	public EventsVO(String eventId, String eventName, String eventDesc, Date eventStart, Date eventEnd, UserVO eventUserId, String eventLocation, String eventAddress, EventTypesVO eventType) {
		this.eventId = eventId;
		this.eventName = eventName;
		this.eventDesc = eventDesc;
		this.eventStart = eventStart;
		this.eventEnd = eventEnd;
		this.eventUserId = eventUserId;
		this.eventLocation = eventLocation;
		this.eventAddress = eventAddress;
		this.eventType = eventType;
	}

	public EventsVO(String eventId) {
		this.eventId = eventId;
		getEvent();
	}

	public void getEvent() {
		MySqlDb db = new MySqlDb();
		String query = "select * from events where event_id = '" + this.eventId + "'";
		try {
			ResultSet rs = db.query(query);
			if (rs != null) {
				while (rs.next()) {
					this.eventId = rs.getString(1);
					this.eventName = rs.getString(2);
					this.eventDesc = rs.getString(3);
					this.eventStart = rs.getDate(4);
					this.eventEnd = rs.getDate(5);
					this.eventUserId = new UserVO(rs.getString(6));
					this.eventLocation = rs.getString(7);
					this.eventAddress = rs.getString(8);
					this.eventType = new EventTypesVO(rs.getString(9));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int insertEvent(EventsVO event, String[] guests, String[] gifts)
	{
		int rows = 0;
		
		if(event != null)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String startDate = sdf.format(event.getEventStart());
			MySqlDb db = new MySqlDb();
			String query = "INSERT INTO events(event_name,event_desc,event_start,event_user_id,event_address,event_type) VALUES('"+event.getEventName()+"','"+event.getEventDesc()+"','"+startDate+"','"+event.getEventUserId().getUserId()+"','"+event.getEventAddress()+"','"+event.getEventType().getEventTypeId()+"')";
			System.out.println(query);
			try {
				rows = db.insertUpdate(query);
				if(rows > 0)
				{
					query = "select max(event_id) from events";
					System.out.println(query);
					ResultSet rs = db.query(query);
					if(rs != null)
					{
						if(rs.next())
						{
							event.setEventId(rs.getString(1));
							
							if(guests != null)
							{
								for(String guest : guests)
								{
									query = "insert into event_guests(event_id, guest_id) values('"+event.getEventId()+"','"+guest+"')";
									System.out.println(query);
									db.insertUpdate(query);
								}
							}
							
							if(gifts != null)
							{
								for(String gift : gifts)
								{
									query = "insert into event_gifts(event_id, gift_id) values('"+event.getEventId()+"','"+gift+"')";
									System.out.println(query);
									db.insertUpdate(query);
								}
							}
							
						}
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return rows;
	}
	
	public EventTypesVO getEventType() {
		return eventType;
	}

	public void setEventType(EventTypesVO eventType) {
		this.eventType = eventType;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventDesc() {
		return eventDesc;
	}

	public void setEventDesc(String eventDesc) {
		this.eventDesc = eventDesc;
	}

	public Date getEventStart() {
		return eventStart;
	}

	public void setEventStart(Date eventStart) {
		this.eventStart = eventStart;
	}

	public Date getEventEnd() {
		return eventEnd;
	}

	public void setEventEnd(Date eventEnd) {
		this.eventEnd = eventEnd;
	}

	public String getEventLocation() {
		return eventLocation;
	}

	public void setEventLocation(String eventLocation) {
		this.eventLocation = eventLocation;
	}

	public String getEventAddress() {
		return eventAddress;
	}

	public void setEventAddress(String eventAddress) {
		this.eventAddress = eventAddress;
	}

	public UserVO getEventUserId() {
		return eventUserId;
	}

	public void setEventUserId(UserVO eventUserId) {
		this.eventUserId = eventUserId;
	}

}
