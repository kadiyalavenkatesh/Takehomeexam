package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.gift.finder.app.db.MySqlDb;

public class GiftCategoryVO {
	private String giftCategoryId;
	private String giftCategoryName;
	private String giftCategoryDesc;
	
	public GiftCategoryVO() {
	}
	
	public GiftCategoryVO(String giftCategoryId, String giftCategoryName, String giftCategoryDesc) {
		this.giftCategoryId = giftCategoryId;
		this.giftCategoryName = giftCategoryName;
		this.giftCategoryDesc = giftCategoryDesc;
	}

	public GiftCategoryVO(String giftCategoryId)
	{
		this.giftCategoryId = giftCategoryId;
		getGiftCategory();
	}

	public void getGiftCategory()
	{
		MySqlDb db = new MySqlDb();
		String query = "select * from gift_category where gift_category_id = '"+this.giftCategoryId+"'";
		try {
			ResultSet rs = db.query(query);
			if(rs != null)
			{
				while(rs.next())
				{
					this.giftCategoryId = rs.getString(1);
					this.giftCategoryName = rs.getString(2);
					this.giftCategoryDesc = rs.getString(3);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String getGiftCategoryId() {
		return giftCategoryId;
	}
	public void setGiftCategoryId(String giftCategoryId) {
		this.giftCategoryId = giftCategoryId;
	}
	public String getGiftCategoryName() {
		return giftCategoryName;
	}
	public void setGiftCategoryName(String giftCategoryName) {
		this.giftCategoryName = giftCategoryName;
	}
	public String getGiftCategoryDesc() {
		return giftCategoryDesc;
	}
	public void setGiftCategoryDesc(String giftCategoryDesc) {
		this.giftCategoryDesc = giftCategoryDesc;
	}
	


}
