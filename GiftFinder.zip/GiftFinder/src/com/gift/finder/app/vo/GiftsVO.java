package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.gift.finder.app.db.MySqlDb;

public class GiftsVO {
	private String giftId;
	private String giftName;
	private String giftDesc;
	private String giftPhoto;
	private GiftCategoryVO giftCategory;
	private String giftUrl;
	
	public GiftsVO() {
		// TODO Auto-generated constructor stub
	}
	
	public GiftsVO(String giftId, String giftName, String giftDesc, String giftPhoto, GiftCategoryVO giftCategory, String giftUrl) {
		this.giftId = giftId;
		this.giftName = giftName;
		this.giftDesc = giftDesc;
		this.giftPhoto = giftPhoto;
		this.giftCategory = giftCategory;
		this.giftUrl = giftUrl;
	}

	public GiftsVO(String giftId)
	{
		this.giftId = giftId;
		getGift();
	}
	
	public void getGift()
	{
		MySqlDb db = new MySqlDb();
		String query = "select * from gifts where gift_id = '"+this.giftId+"'";
		try {
			ResultSet rs = db.query(query);
			if(rs != null)
			{
				while(rs.next())
				{
					this.giftId = rs.getString(1);
					this.giftName = rs.getString(2);
					this.giftDesc = rs.getString(3);
					this.giftPhoto = rs.getString(4);
					this.giftCategory = new GiftCategoryVO(rs.getString(5));
					this.giftUrl = rs.getString(6);
					
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getGiftId() {
		return giftId;
	}
	public void setGiftId(String giftId) {
		this.giftId = giftId;
	}
	public String getGiftName() {
		return giftName;
	}
	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}
	public String getGiftDesc() {
		return giftDesc;
	}
	public void setGiftDesc(String giftDesc) {
		this.giftDesc = giftDesc;
	}
	public String getGiftPhoto() {
		return giftPhoto;
	}
	public void setGiftPhoto(String giftPhoto) {
		this.giftPhoto = giftPhoto;
	}
	
	public String getGiftUrl() {
		return giftUrl;
	}
	public void setGiftUrl(String giftUrl) {
		this.giftUrl = giftUrl;
	}
	public GiftCategoryVO getGiftCategory() {
		return giftCategory;
	}
	public void setGiftCategory(GiftCategoryVO giftCategory) {
		this.giftCategory = giftCategory;
	}
	

}
