package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.gift.finder.app.db.MySqlDb;

public class EventTypesVO {
	private String eventTypeId;
	private String eventTypeName;
	private String eventTypeDesc;
	
	public EventTypesVO() {
	}
	
	public EventTypesVO(String eventTypeId, String eventTypeName, String eventTypeDesc) {
		this.eventTypeId = eventTypeId;
		this.eventTypeName = eventTypeName;
		this.eventTypeDesc = eventTypeDesc;
	}

	public EventTypesVO(String eventTypeId)
	{
		this.eventTypeId = eventTypeId;
		getEventType();
	}
	
	public void getEventType()
	{
		MySqlDb db = new MySqlDb();
		String query = "select * from event_types where event_type_id = '"+eventTypeId+"'";
		try {
			ResultSet rs = db.query(query);
			if(rs != null)
			{
				while(rs.next())
				{
					this.eventTypeId = rs.getString(1);
					this.eventTypeName = rs.getString(2);
					this.eventTypeDesc = rs.getString(3);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public String getEventTypeId() {
		return eventTypeId;
	}
	public void setEventTypeId(String eventTypeId) {
		this.eventTypeId = eventTypeId;
	}
	public String getEventTypeName() {
		return eventTypeName;
	}
	public void setEventTypeName(String eventTypeName) {
		this.eventTypeName = eventTypeName;
	}
	public String getEventTypeDesc() {
		return eventTypeDesc;
	}
	public void setEventTypeDesc(String eventTypeDesc) {
		this.eventTypeDesc = eventTypeDesc;
	}
	

}
