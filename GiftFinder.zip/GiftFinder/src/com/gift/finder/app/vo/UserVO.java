package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.gift.finder.app.db.MySqlDb;

public class UserVO {

	private String userId;
	private String userName;
	private String password;
	private String fullName;
	private String email;
	private CountryVO country;
	private String city;
	private String address;

	public UserVO() {
	}

	public UserVO(String userName, String password, String fullName, String email, String country, String city, String address) {
		this.userName = userName;
		this.password = password;
		this.fullName = fullName;
		this.email = email;
		this.country = new CountryVO(country);
		this.city = city;
		this.address = address;
	}

	public UserVO(String userName) {
		this.userName = userName;
		getUser();
	}

	public void getUser() {
		if (userName != null) {
			MySqlDb db = new MySqlDb();
			String query = "select * from users where user_name = '" + this.userName + "'";
			try {
				ResultSet rs = db.query(query);
				if (rs != null) {
					if (rs.next()) {
						this.userId = rs.getString(1);
						this.userName = rs.getString(2);
						this.password = rs.getString(3);
						this.email = rs.getString(4);
						this.fullName = rs.getString(5);
						this.address = rs.getString(6);
						this.city = rs.getString(7);
						this.country = new CountryVO(rs.getString(8));
					}
					else
					{
						String query1 = "select * from users where user_id = '" + this.userName + "'";
						ResultSet rs1 = db.query(query1);
						if(rs1 != null)
						{
							if(rs1.next())
							{
								this.userId = rs1.getString(1);
								this.userName = rs1.getString(2);
								this.password = rs1.getString(3);
								this.email = rs1.getString(4);
								this.fullName = rs1.getString(5);
								this.address = rs1.getString(6);
								this.city = rs1.getString(7);
								this.country = new CountryVO(rs1.getString(8));
							}
						}
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public int insertUser() {
		MySqlDb db = new MySqlDb();
		int rows = 0;
		String query = "INSERT INTO users(user_name,user_pwd,user_email,user_fullname,user_address,user_city,user_country_code) VALUES('" + userName + "','" + password + "','" + email + "','" + fullName + "','" + address + "','" + city + "','" + country.getCountryCode() + "')";
		System.out.println(query);
		try {
			rows = db.insertUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rows;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCity() {
		return city;
	}

	public CountryVO getCountry() {
		return country;
	}

	public void setCountry(CountryVO country) {
		this.country = country;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
