package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.gift.finder.app.db.MySqlDb;

public class CountryVO {
	private String countryId;
	private String countryCode;
	private String countryName;
	
	public CountryVO() {
		// TODO Auto-generated constructor stub
	}
	
	public CountryVO(String countryId, String countryCode, String countryName) {
		this.countryId = countryId;
		this.countryCode = countryCode;
		this.countryName = countryName;
	}

	public CountryVO(String countryCode)
	{
		this.countryCode = countryCode;
		getCountry();
	}
	
	public void getCountry()
	{
		MySqlDb db = new MySqlDb();
		String query = "select * from country_details where country_code = '"+countryCode+"'";
		try {
			ResultSet rs = db.query(query);
			if(rs != null)
			{
				while(rs.next())
				{
					this.countryId = rs.getString(1);
					this.countryCode = rs.getString(2);
					this.countryName = rs.getString(3);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	

}
