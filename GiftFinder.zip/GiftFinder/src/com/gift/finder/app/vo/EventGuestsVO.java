package com.gift.finder.app.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.gift.finder.app.db.MySqlDb;

public class EventGuestsVO {

	private EventsVO eventId;
	private UserVO guestId;
	private GuestStatusVO guestStatus;

	public EventGuestsVO() {
		// TODO Auto-generated constructor stub
	}

	public EventGuestsVO(EventsVO eventId, UserVO guestId, GuestStatusVO guestStatus) {
		this.eventId = eventId;
		this.guestId = guestId;
		this.guestStatus = guestStatus;
	}

	public EventGuestsVO(EventsVO eventId) {
		this.eventId = eventId;
		getEventGuest();
	}

	public void getEventGuest() {
		MySqlDb db = new MySqlDb();
		String query = "select * from event_guests where event_id = '" + eventId.getEventId() + "' and gift_id = '" + guestId.getUserId() + "'";
		try {
			ResultSet rs = db.query(query);
			if (rs != null) {
				while (rs.next()) {
					this.eventId = new EventsVO(rs.getString(1));
					this.guestId = new UserVO(rs.getString(2));
					this.guestStatus = new GuestStatusVO(rs.getString(3));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public EventsVO getEventId() {
		return eventId;
	}

	public void setEventId(EventsVO eventId) {
		this.eventId = eventId;
	}

	public UserVO getGuestId() {
		return guestId;
	}

	public void setGuestId(UserVO guestId) {
		this.guestId = guestId;
	}

	public GuestStatusVO getGuestStatus() {
		return guestStatus;
	}

	public void setGuestStatus(GuestStatusVO guestStatus) {
		this.guestStatus = guestStatus;
	}

}
