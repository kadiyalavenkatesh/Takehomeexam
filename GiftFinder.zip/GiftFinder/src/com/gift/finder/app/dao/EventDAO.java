package com.gift.finder.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gift.finder.app.db.MySqlDb;
import com.gift.finder.app.vo.EventGiftsVO;
import com.gift.finder.app.vo.EventGuestsVO;
import com.gift.finder.app.vo.EventTypesVO;
import com.gift.finder.app.vo.EventsVO;
import com.gift.finder.app.vo.GiftStatusVO;
import com.gift.finder.app.vo.GiftsVO;
import com.gift.finder.app.vo.GuestStatusVO;
import com.gift.finder.app.vo.UserVO;

public class EventDAO {
	
	public List<EventTypesVO> listAllEventTypes()
	{
		List<EventTypesVO> allEventTypes = new ArrayList<EventTypesVO>(); 
		
		MySqlDb db = new MySqlDb();
		String query = "select * from event_types";
		try {
			ResultSet rs = db.query(query);
			if(rs != null)
			{
				while(rs.next())
				{
					String eventTypeId = rs.getString(1);
					String eventTypeName = rs.getString(2);
					String eventTypeDesc = rs.getString(3);
					EventTypesVO eventType = new EventTypesVO(eventTypeId, eventTypeName, eventTypeDesc);
					
					allEventTypes.add(eventType);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return allEventTypes;
	}
	
	public List<EventGiftsVO> listAllEventGifts(EventsVO eventVO)
	{
		List<EventGiftsVO> allEventGiftsVO = new ArrayList<EventGiftsVO>();
		
		if(eventVO != null)
		{
			MySqlDb db = new MySqlDb();
			String query = "select * from event_gifts where event_id = '"+eventVO.getEventId()+"'";
			try {
				ResultSet rs = db.query(query);
				if(rs != null)
				{
					while(rs.next())
					{
						GiftsVO giftId = new GiftsVO(rs.getString(2));
						GiftStatusVO giftStatus = new GiftStatusVO(rs.getString(3));
						
						EventGiftsVO eventGift = new EventGiftsVO(eventVO, giftId, giftStatus);
						
						allEventGiftsVO.add(eventGift);
						
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return allEventGiftsVO;
	}
	
	public List<EventGuestsVO> listAllEventGuests(EventsVO eventVO)
	{
		List<EventGuestsVO> allEventGuestsVO = new ArrayList<EventGuestsVO>();
		
		if(eventVO != null)
		{
			MySqlDb db = new MySqlDb();
			String query = "select * from event_guests where event_id = '"+eventVO.getEventId()+"'";
			try {
				ResultSet rs = db.query(query);
				if(rs != null)
				{
					while(rs.next())
					{
						UserVO userVO = new UserVO(rs.getString(2));
						GuestStatusVO guestStatus = new GuestStatusVO(rs.getString(3));
						
						EventGuestsVO eventGuest = new EventGuestsVO(eventVO, userVO, guestStatus);
						
						allEventGuestsVO.add(eventGuest);
						
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return allEventGuestsVO;
	}
}
