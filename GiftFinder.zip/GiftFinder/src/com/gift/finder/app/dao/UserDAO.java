package com.gift.finder.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gift.finder.app.db.MySqlDb;
import com.gift.finder.app.vo.EventsVO;
import com.gift.finder.app.vo.UserVO;

public class UserDAO {
	
	public List<EventsVO> listAllUpComingEvents(UserVO user)
	{
		List<EventsVO> allEvents = new ArrayList<EventsVO>();
		
		if(user != null && user.getUserId() != null && !user.getUserId().equals(""))
		{
			MySqlDb db = new MySqlDb();
			String query = "SELECT event_id FROM events WHERE event_start >= curtime() and event_user_id = '"+user.getUserId()+"' order by event_start";
			try {
				ResultSet rs = db.query(query);
				if(rs != null)
				{
					while(rs.next())
					{
						EventsVO event = new EventsVO(rs.getString(1));
						allEvents.add(event);
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return allEvents;
	}
	
	public List<EventsVO> listAllUpComingInvitedEvents(UserVO user)
	{
		List<EventsVO> allEvents = new ArrayList<EventsVO>();
		
		if(user != null && user.getUserId() != null && !user.getUserId().equals(""))
		{
			MySqlDb db = new MySqlDb();
			String query = "select e.event_id from events e, event_guests eg where e.event_id = eg.event_id and curtime() <= e.event_start and eg.guest_id = '"+user.getUserId()+"'";
			try {
				ResultSet rs = db.query(query);
				if(rs != null)
				{
					while(rs.next())
					{
						EventsVO event = new EventsVO(rs.getString(1));
						allEvents.add(event);
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return allEvents;
	}
	
	public List<UserVO> listAllGuests(UserVO user)
	{
		List<UserVO> allGuests = new ArrayList<UserVO>();
		
		if(user != null && user.getUserId() != null && !user.getUserId().equals(""))
		{
			MySqlDb db = new MySqlDb();
			String query = "select * from users where user_id <> '"+user.getUserId()+"'";
			try {
				ResultSet rs = db.query(query);
				if(rs != null)
				{
					while(rs.next())
					{
						String userId = rs.getString(1);
						String userName = rs.getString(2);
						String password = rs.getString(3);
						String email = rs.getString(4);
						String fullName = rs.getString(5);
						String address = rs.getString(6);
						String city = rs.getString(7);
						String country = rs.getString(8);
						UserVO userVO = new UserVO(userName, password, fullName, email, country, city, address);
						userVO.setUserId(userId);
						allGuests.add(userVO);
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return allGuests;
	}
	
}
