package com.gift.finder.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gift.finder.app.db.MySqlDb;
import com.gift.finder.app.vo.EventTypesVO;
import com.gift.finder.app.vo.GiftCategoryVO;
import com.gift.finder.app.vo.GiftsVO;

public class GiftsDAO {

	public List<GiftsVO> listAllGifts() {
		List<GiftsVO> allGifts = new ArrayList<GiftsVO>();

		MySqlDb db = new MySqlDb();
		String query = "select * from gifts";
		try {
			ResultSet rs = db.query(query);
			if (rs != null) {
				while (rs.next()) {
					String giftId = rs.getString(1);
					String giftName = rs.getString(2);
					String giftDesc = rs.getString(3);
					String giftPhoto = rs.getString(4);
					GiftCategoryVO giftCategory = new GiftCategoryVO(rs.getString(5));
					String giftUrl = rs.getString(6);
					GiftsVO gift = new GiftsVO(giftId, giftName, giftDesc, giftPhoto, giftCategory, giftUrl);
					allGifts.add(gift);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allGifts;
	}

	public List<GiftCategoryVO> listAllGiftCategories() {
		List<GiftCategoryVO> allGiftCategories = new ArrayList<GiftCategoryVO>();

		MySqlDb db = new MySqlDb();
		String query = "select * from gift_category";
		try {
			ResultSet rs = db.query(query);
			if (rs != null) {
				while (rs.next()) {
					String giftCategoryId = rs.getString(1);
					String giftCategoryName = rs.getString(2);
					String giftCategoryDesc = rs.getString(3);
					GiftCategoryVO eventType = new GiftCategoryVO(giftCategoryId, giftCategoryName, giftCategoryDesc);

					allGiftCategories.add(eventType);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return allGiftCategories;
	}

}
