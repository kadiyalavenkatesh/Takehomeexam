package com.gift.finder.app.util;

public class GiftFinderUtility {

	public boolean checkNullorEmpty(String value) {
		if (value == null || value.equals(""))
			return true;
		return false;
	}

}
