package com.gift.finder.app.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.gift.finder.app.constants.GiftFinderConstants;

public class MySqlDb {

	private String hostName = GiftFinderConstants.MYSQL_HOST;
	private String port = GiftFinderConstants.MYSQL_PORT;
	private String databaseName = GiftFinderConstants.MYSQL_DB_NAME;
	private String userName = GiftFinderConstants.MYSQL_USER;
	private String password = GiftFinderConstants.MYSQL_PWD;
	private Connection connection;
	private Statement statement;

	public MySqlDb() {
		openConnection();
	}

	public Connection openConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://" + hostName + ":" + port + "/" + databaseName;
			connection = (Connection) DriverManager.getConnection(url, userName, password);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return getConnection();
	}

	protected void finalize() throws Throwable {
		closeConnection();
	}

	public void closeConnection() {
		try {
			if (connection != null) {
				System.out.println("Connection Closed");
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ResultSet query(String query) throws SQLException {
		if (getConnection() == null) {
			this.openConnection();
		}
		statement = getConnection().createStatement();
		ResultSet res = statement.executeQuery(query);
		return res;
	}

	/**
	 * @desc Method to insert / update / delete data to a table
	 * @param insertQuery
	 *            String The Insert query
	 * @return boolean
	 * @throws SQLException
	 */
	public int insertUpdate(String insertQuery) throws SQLException {
		if (getConnection() == null) {
			this.openConnection();
		}
		statement = getConnection().createStatement();
		int result = statement.executeUpdate(insertQuery);
		return result;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
}
