package com.gift.finder.app.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gift.finder.app.vo.EventTypesVO;
import com.gift.finder.app.vo.EventsVO;
import com.gift.finder.app.vo.UserVO;

/**
 * Servlet implementation class CreateEvent
 */
@WebServlet("/CreateEvent")
public class CreateEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CreateEvent() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String eventName = request.getParameter("eventName");
		String eventDesc = request.getParameter("eventDesc");
		String startDate = request.getParameter("eventDate");
		String address = request.getParameter("eventAddr");
		String[] guests = request.getParameterValues("guests");
		String[] gifts = request.getParameterValues("gifts");

		System.out.println(eventName + " " + eventDesc + " " + startDate + " " + address + " " + guests + " " + gifts);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		PrintWriter out = response.getWriter();
		String eventName = request.getParameter("eventName");
		String eventDesc = request.getParameter("eventDesc");
		String startDate = request.getParameter("eventDate");
		String address = request.getParameter("eventAddr");
		String eventType = request.getParameter("eventType");
		EventTypesVO eventTypeVO = new EventTypesVO(eventType);
		String[] guests = request.getParameterValues("guests");
		String[] gifts = request.getParameterValues("gifts");
		
		Date eventStartDate = new Date();
		try {
			eventStartDate = formatter.parse(startDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HttpSession session = request.getSession();
		
		UserVO user = (UserVO) session.getAttribute("user");
		
		EventsVO event = new EventsVO("", eventName, eventDesc, eventStartDate, new Date(), user, "", address, eventTypeVO);
		
		int rows = event.insertEvent(event, guests, gifts);
		if(rows > 0)
			out.print("success");
		else
			out.print("failure");
		
		System.out.println(eventName + " " + eventDesc + " " + startDate + " " + address + " " + eventType + " " + guests + " " + gifts);

	}

}
