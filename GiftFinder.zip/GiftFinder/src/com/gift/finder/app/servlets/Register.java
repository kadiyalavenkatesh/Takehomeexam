package com.gift.finder.app.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gift.finder.app.util.GiftFinderUtility;
import com.gift.finder.app.vo.UserVO;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Register() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/plain");
		GiftFinderUtility gfu = new GiftFinderUtility();
		PrintWriter out = response.getWriter();
		
		System.out.println("Inside doPost Register");
		
		String fullName = request.getParameter("fullname");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String city = request.getParameter("city");
		String country = request.getParameter("country");
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		String rePassword = request.getParameter("rpassword");
		
		if (!(gfu.checkNullorEmpty(fullName) || gfu.checkNullorEmpty(email) || gfu.checkNullorEmpty(address) || gfu.checkNullorEmpty(city) || gfu.checkNullorEmpty(country) || gfu.checkNullorEmpty(userName) || gfu.checkNullorEmpty(password) || gfu.checkNullorEmpty(rePassword))) {
			UserVO user = new UserVO(userName, rePassword, fullName, email, country, city, address);
			System.out.println("Inserting User");
			if (user.insertUser() > 0)
				out.print("success");
			else
				out.print("fail");
		}
	}

}
