package com.gift.finder.app.servlets;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gift.finder.app.db.MySqlDb;
import com.gift.finder.app.vo.UserVO;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		MySqlDb db = new MySqlDb();
		String query = "select * from users where user_name = '" + userName + "' and  user_pwd ='" + password + "'";
		UserVO user;
		try {
			ResultSet rs = db.query(query);
			if (rs != null) {
				if(rs.next()) {
					user = new UserVO(userName);
					session.setAttribute("user", user);
					response.sendRedirect("index.jsp");
				}
				else
				{
					response.sendRedirect("login.html");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			response.sendRedirect("login.html");
		}
	}

}
